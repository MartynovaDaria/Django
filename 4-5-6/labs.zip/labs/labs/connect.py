import pymysql


# class connection:
#     def __init__(self, user, password, db, host='localhost'):
#         self.user = user
#         self.host = host
#         self.password = password
#         self.db = db
#         self._connection_ = None
#
#
# @property
# def connection(self):
#     return self._connection_
#
#
# def _enter_(self):
#     self.connect()
#
#
# def _exit_(self, exc_type, exc_val, exc_tb):
#     self.disconect()
#
#
# def connect(self):
#     if not self._connection_:
#         self._connection = pymysql.connect(
#             host=self.host,
#             user=self.user,
#             passwd=self.password,
#             db=self.db
#         )
#
#
# def disconnect(self):
#     if self._connection_:
#         self._connection_.close()

import pymysql

db = pymysql.connect(db='django',
                     host='localhost',
                     user='daria',
                     password='123')
c = db.cursor()

c.execute("insert into goods (name, supplier) values (%s, %s);",('chair', 'LeroyMerlin'))
db.commit()

c.execute('select * from goods;')

entries = c.fetchall()

for e in entries:
    print(e)

c.close()
db.close()
