from django import forms

class SignUpForm(forms.Form):
    username = forms.CharField(min_length=5,label='Логин')
    password = forms.CharField(min_length=4, widget=forms.PasswordInput, label='Пароль')


class LogInForm(forms.Form):
    username = forms.CharField(min_length=5,label='Логин')
    password = forms.CharField(min_length=4, widget=forms.PasswordInput, label='Пароль')