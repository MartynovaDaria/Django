from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.views.generic import TemplateView
from django.views import generic
from .models import Goods, Users
from .forms import *
from django.contrib.auth.models import User


class GoodsView(TemplateView):
    def get(self, request):
        data = Goods.objects.all()
        print(data)
        return render(request, 'goods.html', {
            "goods": data
        })


def SignUp(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            u = User.objects.create_user(username=request.POST.get('username'), password=request.POST.get('password'))
            u.save()
            return HttpResponseRedirect('/log_in')
    else:
        form = SignUpForm()
    return render(request, 'sign_up.html', {'form': form})


@login_required(login_url='/log_in')
def LogIn(request):
    if request.method == 'POST':
        form = LogInForm(request.POST)
        if form.is_valid():
            username = request.POST.get('username')
            password = request.POST.get('password')
            u = Users(login=username, password=password)
            u.save()
            user = authenticate(username=username, password=password)
            if user:
                return render(request, 'profile.html', {'form': form, 'username': user})
    else:
        form = LogInForm()
    return render(request, 'log_in.html', {'form': form})


def logout_view(request):
    if request.method == 'POST':
        form = request.POST
        if request.GET.get('logout'):
            logout(request)


class ProfileView(TemplateView):
    def get(self, request, *args, **kwargs):
        return render(request, 'profile.html')



def function_view(request):
    return HttpResponse('response from function view')


class ExampleClassBased(TemplateView):
    def get(self, request):
        return HttpResponse('response from lass based view')


class ExampleView(TemplateView):
    def get(self, request):
        return render(request, 'temp1.html', {'my_variable': {'a': 'Это переменная'}})


class OrdersView(TemplateView):
    def get(self, request):
        data = {
            'orders': [
                {'title': 'Первый заказ', 'id': 1},
                {'title': 'Второй заказ', 'id': 2},
                {'title': 'Третий заказ', 'id': 3}
            ]
        }
        return render(request, 'orders.html', data)


class OrderView(TemplateView):
    def get(self, request, id):
        data = {
            'order': {
                'id': id
            }
        }
        return render(request, 'order.html', data)
