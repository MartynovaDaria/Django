from django.db import models


class Users(models.Model):
    login = models.CharField(max_length=40)
    password = models.CharField(max_length=40)


class Goods(models.Model):
    name = models.CharField(max_length=40)
    supplier = models.CharField(max_length=70)
    description = models.CharField(max_length=255)


# class User_Order(models.Model):
#     user = models.ForeignKey('User', on_delete=models.CASCADE)
#     order = models.IntegerField(primary_key=True)
#
#
# class Order_Goods(models.Model):
#     order = models.ForeignKey('User_Order', on_delete=models.DO_NOTHING)
#     good = models.ForeignKey('Goods', on_delete=models.DO_NOTHING)
